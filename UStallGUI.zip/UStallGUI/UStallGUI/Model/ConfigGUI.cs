﻿namespace UStallGUI.Model
{
    public class ConfigGUI
    {
        public int ComPort { get; set; } = 15;
        public bool GyroEnabled { get; set; } = true;
    }
}