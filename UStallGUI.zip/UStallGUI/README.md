# UStallGUI GitHub

**Table of Contents**

[[_TOC_]]

functionality of the GUI

## GUI

- Documentation following soon

## Changelog

- **17 April 2025**: Initial version of the document.
